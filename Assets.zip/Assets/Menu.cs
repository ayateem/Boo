using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    private int currLvlIndex = 1;
    public void PressPlayButton()
    {
        SceneManager.LoadScene(currLvlIndex);
        
    }

    public void PressQuitButton()
    {
        Application.Quit();
    }

    public void CompleteLevel()
    {
        currLvlIndex++;

        if (currLvlIndex < SceneManager.sceneCountInBuildSettings)
        {
            SceneManager.LoadScene(currLvlIndex);
        }
        else
        {
            Debug.Log("You have completed the game! Congratulations!");
        }
    }
}
   