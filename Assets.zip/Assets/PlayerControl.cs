using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
 public float speedMove = 3f;
    public GameObject ghost;
    public float distSafe = 2f;

    private bool gameIsOver = false;

    void Update()
    {
        if (!gameIsOver)
        {
            float horizontal = Input.GetAxis("Horizontal");
            float vertical = Input.GetAxis("Vertical");
            Vector3 movement = new Vector3(horizontal, 0f, vertical) * speedMove * Time.deltaTime;
            transform.Translate(movement);
            float distToGhost = Vector3.Distance(transform.position, ghost.transform.position);
            if (distToGhost < distSafe)
            {
                GameOver();
            }
        }
    }


    void GameOver()
    {
        Debug.Log("Game Over");
        gameIsOver = true;
    }
}





