using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class DoorControl : MonoBehaviour
{
    private bool isTheLevelCompleted = false;
    public GhostControl ghostControl;
   

    private void OnTriggerEnter (Collider other)
    {
        if (other.CompareTag("Player") && !isTheLevelCompleted)
        {
            isTheLevelCompleted = true;
        if (ghostControl != null)
        {
            ghostControl.StopGhostMove();
        }

            Debug.Log("Congratulations. You have completed this level!");
           
          LoadTheNextLevel();
        }
        }

        private void LoadTheNextLevel()
        {
            int currSceneIndex = SceneManager.GetActiveScene().buildIndex;
            int nextSceneIndex = currSceneIndex + 1;

            if (nextSceneIndex < SceneManager.sceneCountInBuildSettings)
            {
                SceneManager.LoadScene(nextSceneIndex);
            }
            else
            {
                Debug.Log("You have completed the game! Congratulations!");
            }
        }
    }