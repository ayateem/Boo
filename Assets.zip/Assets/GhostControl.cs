using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GhostControl : MonoBehaviour
{
    public float speedMove = 4f;
    public float rangeMove = 10f; 


    private Vector3 originalPos;
    private bool movingRandom = true;
    private Vector3 targetPos;


    private void Start()
    {
        originalPos = transform.position;
        StartCoroutine(UpdateTargetPosition());
    }

    private void Update()
    {
        if (movingRandom)
        {
            if (Vector3.Distance(transform.position, targetPos) <= 0.1f)
            {
                targetPos = GetRandomPosition();
            }
            Vector3 directionMove = targetPos - transform.position;
            directionMove.Normalize();
            transform.Translate(directionMove * speedMove * Time.deltaTime);
        }
    }

    private Vector3 GetRandomPosition()
    {
        Vector3 randomDir = Random.insideUnitSphere * rangeMove;
        randomDir.y = 0f;
        Vector3 randomPos = originalPos + randomDir;

        randomPos.x = Mathf.Clamp(randomPos.x, originalPos.x - rangeMove, originalPos.x + rangeMove);
        randomPos.z = Mathf.Clamp(randomPos.z, originalPos.z - rangeMove, originalPos.z + rangeMove);

        return randomPos;
    }

    private System.Collections.IEnumerator UpdateTargetPosition()
    {
        while (true)
        {
            targetPos = GetRandomPosition();
            
            yield return new WaitForSeconds(3f);
        }
    }

    public void StopGhostMove()
    {
        movingRandom = false;
    }

    public void ContinueGhostMove()
    {
        movingRandom = true;
    }
}
    
